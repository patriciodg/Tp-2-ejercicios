#include <stdio.h>
#include <conio.h>

int main()
{
	char nombre[50];
	printf("Ingrese un nombre: ");
	scanf("%s", &nombre);
	system("pause");
	system("cls");
	printf("El nombre ingresado fue: %s", nombre);
}
