#include <stdio.h>
#include <conio.h>
#include <string.h>


int main()
{
	char cadena[50];
	printf("Ingrese una cadena de caracteres: ");
	scanf("%s", &cadena);
	int longitud,cont=0,x;
	longitud = strlen(cadena);
	for(x=0;x<longitud;x++)
	{
		if(cadena[x]=='A' || cadena[x]=='a' || cadena[x]=='E' || cadena[x]=='e' || cadena[x]=='I' || cadena[x]=='i' || cadena[x]=='O' || cadena[x]=='o' || cadena[x]=='U' || cadena[x]=='u' )
		{
			cont++;
		}
	}
	printf("La cantidad de vocales es: %d", cont);	
}
