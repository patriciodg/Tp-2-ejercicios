#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
	int x;
	char cadena[50];
	char car;
	char reemp;
	printf("Ingrese una cadena de caracteres: ");
	gets(cadena);
	system("cls");
	
	printf("Ingrese el caracter que desea reemplazar: ");
	scanf("%c", &car);
	fflush(stdin);
	system("cls");
	
	printf("Ingrese el caracter por el cual lo desea reemplazar: ");
	scanf("%c", &reemp);
	
	for(x=0;x<strlen(cadena);x++)
	{
		if(cadena[x]==car)
		{
			cadena[x]=reemp;
		}
	}
	printf("%s", cadena);
}
