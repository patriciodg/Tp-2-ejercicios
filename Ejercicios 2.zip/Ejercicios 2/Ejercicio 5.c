#include <stdio.h>
#include <conio.h>
#include <string.h>





int main()
{
	char cadena[50];
	char caracter1,caracter2;
	int longitud,x;
	
	printf("Ingrese una cadena de caracteres: ");
	scanf("%s", cadena);
	system("cls");
	fflush(stdin);
	printf("Ingrese el caracter que desea reemplazar: ");
	scanf("%c", &caracter1);
	fflush(stdin);
	system("cls");
	printf("Ingrese el caracter con el cual lo desea reemplazar: ");
	scanf("%c", &caracter2);
	system("cls");
	
	longitud = strlen(cadena);
	
	for(x=0;x<longitud;x++)
	{
		if(cadena[x]==caracter1)
		{
			cadena[x]=caracter2;
		}
	}
	printf("La cadena con los caracteres reemplazados es: %s", cadena);
	
}
