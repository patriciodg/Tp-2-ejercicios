#include <stdio.h>
#include <string.h>
#include <conio.h>

int main()
{
    int cont = 0, x, y, longitud1, longitud2;
    char cadena_1[50];
    char cadena_2[50];
    char copia[50];
    
    
    printf("Ingrese la primer cadena de caracteres: ");
    scanf("%s", cadena_1);
    system("cls");
    printf("Ingrese la segunda cadena de caracteres: ");
    scanf("%s", cadena_2);
    system("cls");
    strcpy(copia, cadena_2);
    longitud1 = strlen(cadena_1);
    longitud2 = strlen(cadena_2);
    

    if (longitud1 == longitud2)
    {
        for (x = 0; x < longitud1; x++)
        {
            for (y = 0; y < longitud2; y++)
            {
                if (cadena_2[y] == cadena_1[x])
                {
                    cont++;
                    cadena_2[y] = ' '; 
                    break; 
                }
            }
        }
        
        if (cont == longitud1)
        {
            printf("%s es un anagrama de %s", copia, cadena_1);
        }
        else
        {
            printf("%s no es un anagrama de %s", copia, cadena_1);
        }
    }
    else
    {
        printf("%s no es un anagrama de %s", copia, cadena_1);
    }

   
}

