#include <stdio.h>
#include <conio.h>


int main()
{
	int x;
	char palabra1[50], palabra2[50], palabra3[50], palabra4[50], palabra5[50], palabracopia[50]={0};
	printf("Ingrese la primer cadena de caracteres: ");
	scanf("%s", palabra1);
	system("cls");
	printf("Ingrese la segunda cadena de caracteres: ");
	scanf("%s", palabra2);
	system("cls");
	printf("Ingrese la tercer cadena de caracteres: ");
	scanf("%s", palabra3);
	system("cls");
	printf("Ingrese la cuarta cadena de caracteres: ");
	scanf("%s", palabra4);
	system("cls");
	printf("Ingrese la quinta cadena de caracteres: ");
	scanf("%s", palabra5);
	system("cls");
	for(x=0;x<50;x++)
	{
		if(palabra1[x]==palabra2[x] && palabra2[x]==palabra3[x] && palabra3[x]==palabra4[x] && palabra4[x]==palabra5[x])
		{
			palabracopia[x]=palabra1[x];
		}
		else
		{
		break;
		}
		
	}
	printf("%s son las coincidencias", palabracopia);
}
