#include <stdio.h>
#include <conio.h>
#include <string.h>

int main()
{
	char oracion[50],copia[50];
	int longitud=0,longitud2=0,x,espacios=0,y=0;
	
	printf("Ingrese una oracion: ");
	fgets(oracion, 50, stdin);
	
	
	
	longitud=strlen(oracion);
	
	for(x=0;x<longitud;x++)
	{
		if(oracion[x]!=' ')
		{
			copia[y]=oracion[x];
			y++;
		}	
	}
	longitud2=strlen(copia);
	printf("%s", copia);
	for(x=0;x<longitud;x++)
	{
		if(oracion[x]>=97&&oracion[x]<=122)
		{
			oracion[x]=oracion[x]-32;
		}
	}
	printf("Oracion toda en mayusculas: %s", oracion);
	for(x=0;x<longitud;x++)
	{
		if(oracion[x]>=65&&oracion[x]<=90)
		{
			oracion[x]=oracion[x]+32;
		}
	}
	printf("Oracion toda en minusculas: %s", oracion);
	printf("Oracion intercalada: ");
	for(x=0;x<longitud2;x++)
	{
		if(x%2==0&&copia[x]>=97&&copia[x]<=122)
		{
			copia[x]=copia[x]-32;
		}
	}
	y=0;
	for(x=0;x<longitud2;x++)
	{
		if(oracion[y]==' ')
		{
			printf(" %c", copia[x]);
			y++;
		}
		else
		{
			printf("%c", copia[x]);
			
		}
		y++;
	}
	
	for(x=0;x<longitud;x++)
	{
		if(oracion[x]==' '&&oracion[x+1]>=97&&oracion[x+1]<=122)
		{
			oracion[x+1]=oracion[x+1]-32;
		}
		else if(x==0&&oracion[x]>=97&&oracion[x]<=122)
		{
			oracion[x]=oracion[x]-32;
		}
	}
	printf("La oracion con mayusculas al inicio de cada palabra es: %s", oracion);
}
